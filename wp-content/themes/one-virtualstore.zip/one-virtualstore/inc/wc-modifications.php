<?php
/* SHOP PAGE MODIFIERS */

//remove sidebar from shop page
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar');
//remove breadcrumb
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
//remove shop title

    
add_filter('woocommerce_show_page_title', 'one_virtualstore_remove_shop_title');
function one_virtualstore_remove_shop_title(){
    $val = false;
    return $val;
}

/* SINGLE PAGE MODIFIERS*/

//remove SKU info from single-product
add_filter('wc_product_sku_enabled', 'one_virtualstore_remove_sku');
function one_virtualstore_remove_sku($val){
    $val = false;
    return $val;
}

add_filter( 'woocommerce_cart_subtotal', 'custom_cart_subtotal_display', 10, 3 );

function your_custom_subtotal_function( $product_subtotal, $product, $quantity, $cart_object ) {
        // Example: Add a custom message after the subtotal if quantity is greater than 2
        if ( $quantity > 2 ) {
            $product_subtotal .= ' <span class="custom-message">(Bulk discount applied)</span>';
        }

        // Example: Change the subtotal format based on product category
        if ( has_term( 'premium-products', 'product_cat', $product->get_id() ) ) {
            $product_subtotal = '<strong>' . $product_subtotal . '</strong>';
        }

        return $product_subtotal;
    }
?>